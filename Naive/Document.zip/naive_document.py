Count ={}
Prob = {}

#if lable name is in Count or Prob array
def CheckName(name):
    All = "All"+name
    #Check All Counting label
    if All not in Count:
        Count[All] = 0
    if All not in Prob:
        Prob[All] = 0

    #Check class name
    if name not in Count:
        Count[name] = {}
    if name not in Prob:
        Prob[name] = {}

def train():
    ##[Stage1] Test case counting
    #f = open("r8-train-all-terms.txt","r")
    f = open("train","r")
    train_number = 0
    for tmp in f:
        tmp = tmp.rstrip().split(" ")
        print(tmp)
        class_name = tmp[0]
        CheckName(class_name)

        #[Stage2] All number counter
        Count["All"+class_name] += 1
        train_number += 1

        #[Stage3] Attribute number counter
        for i in tmp[1:]:
            if i not in Count[class_name]:
                Count[class_name][i] = 1
            else:
                Count[class_name][i] += 1
    f.close()
    print(Count)

    ##[Stage2] Calc Probility
    for name in Count:
        if name[:3] == "All":
            Prob[name] = Count[name]/train_number
        else:
            for i in Count[name]:
                Prob[name][i] = Count[name][i] / Count["All"+name]
    print(Prob)

def Check():
    f = open("train","r")
    allcount = 0
    match = 0
    for i in f:
        allcount += 1
        tmp = i.rstrip().split(",")
        target = tmp[0].split("\t")
        result = ""
        YesProb = 1
        NoProb = 1
        for j in tmp[1:]:
            #Yes
            if j not in Prob["Yes"]:
                YesProb = YesProb * 0
            else:
                YesProb = YesProb * Prob["Yes"][j]

            if j not in Prob["No"]:
                NoProb = NoProb * 0
            else:
                NoProb = NoProb * Prob["No"][j]

        ResultYes = Prob["AllYes"]*YesProb
        ResultNo = Prob["AllNo"]*NoProb
        if ResultYes >= ResultNo:
            result = "Yes"
        else:
            result = "No"

        if target == result:
            match += 1

    print("Accuracy: %lf" %((match/allcount)*100))
    f.close()

def main():
    train()
    #Check()

if __name__ == '__main__':
    main()